ILA Developer Files v3.8
--------------------------

You've just downloaded the most recent developer files for ILA voice assistant :-)
These files are intended to be used with the full version of ILA. Please download
the developer version 3.8 from ILA's homepage to get started:

https://sites.google.com/site/ilavoiceassistant/downloads

The developer package will give you the ability to write your own add-ons for ILA and help you adapt the program to other languages.
It is intended for the use in your favourite Java editor (tested in Eclipse). 

For more info and tutorials check out ILA's homepage: https://sites.google.com/site/ilavoiceassistant/
If you have any questions or want to share your project please post here: https://sourceforge.net/p/ila-voice-assistant/discussion/

Have fun! 
Florian